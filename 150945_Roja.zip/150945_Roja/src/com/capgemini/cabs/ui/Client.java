package com.capgemini.cabs.ui;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.cab.service.ICabService;
import com.capgemini.cab.service.CabService;
import com.capgemini.cabs.bean.*;



public class Client {
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		
		
		
		try 
		{
			boolean retry=false;
			String phoneNumber,customerName,addressOfPickup,pincode;
		
			ICabService s1=new CabService();
			CabRequest b1=new CabRequest();
			Scanner sc=new Scanner(System.in);
			do
			{
				retry=false;
				System.out.println("1. Raise Cab Request");
				System.out.println("2. view Cab Request Status");
				System.out.println("3.exit");
				System.out.println("Enter your choice");
				int choice=sc.nextInt();
				if(choice==1)
				{
					retry=true;
					do
					{
						System.out.println("Enter the name of customer:");
						  customerName=sc.next();
					}while(!s1.isValidcustomerName(customerName));
					b1.setCustomerName(customerName);
					
					do
					{	
						System.out.println("Enter customer phone number :");
						phoneNumber=sc.next();
					}while(!s1.isValidMobile(phoneNumber));
					
					b1.setPhoneNumber(phoneNumber);
					System.out.println("Enter Pick up address :");
					addressOfPickup=sc.next();
					b1.setAddressOfPickup(addressOfPickup);
					System.out.println("Enter Pin Code:");
					pincode=sc.next();
					b1.setPincode(pincode);
					s1.retrieveCabNumber(pincode);
					b1.setCabNumber(s1.retrieveCabNumber(pincode));
					s1.addCabRequestDetails(b1);
					System.out.println(b1.getRequestStatus());
					
					
				}
				else if(choice==2)
				{
					retry=true;
					System.out.println("Enter your request Id :");
					int requestId=sc.nextInt();
					retry=s1.getRequestDetails(requestId,b1);
				}
				else 
				{
					System.out.println("Thank you");
					System.exit(0);
				}
			}while(!retry);
				
	
	}
	catch(InputMismatchException e)
	{
		logger.error("Exception Occured"+e);
		System.out.println(e);
	}
	catch(ClassCastException ce)
	{
		logger.error("Exception Occured"+ce);
		System.out.println(ce);
	}
	catch(NullPointerException npe)
	{
		logger.error("Exception Occured"+npe);
		System.out.println(npe);
	}

 catch (Exception e) {
		
	System.out.println("exception occured"+e.getMessage());
	}

}
}
