package com.capgemini.cabs.bean;

public class CabRequest {
	
	private int requestId;
	private String customerName;
	private String phoneNumber;
	private String dateOfRequest;
	private String requestStatus;
	private String cabNumber;
	private String addressOfPickup;
	private String pincode;
	private String status;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getRequestId() {
		return requestId;
	}
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getDateOfRequest() {
		return dateOfRequest;
	}
	public void setDateOfRequest(String dateOfRequest) {
		this.dateOfRequest = dateOfRequest;
	}
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	public String getCabNumber() {
		return cabNumber;
	}
	public void setCabNumber(String cabNumber) {
		this.cabNumber = cabNumber;
	}
	public String getAddressOfPickup() {
		return addressOfPickup;
	}
	public void setAddressOfPickup(String i) {
		this.addressOfPickup = i;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String toString()
	{
		return "\nName of the Customer:"+this.customerName+"\nResuest Status:"+this.status+"\ncab number:"+this.cabNumber+"\nPckup Address:"+this.addressOfPickup;
	}
	
	
}
