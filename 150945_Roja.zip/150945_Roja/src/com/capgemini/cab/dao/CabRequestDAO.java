package com.capgemini.cab.dao;
import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.cabs.bean.CabRequest;
import com.capgemini.cab.service.*;
import com.capgemini.cab.util.DBConnection;


public class CabRequestDAO implements ICabRequestDAO{


private static boolean created=true;
	
	Logger logger=Logger.getRootLogger();
	public CabRequestDAO()
	{
	PropertyConfigurator.configure("resources//log4j.properties");

	}

	@Override
	public StringBuilder displaycabDetails() throws Exception 
	{
	
		
		try 
		{
			Connection conn = com.capgemini.cab.util.DBConnection.getInstance().getConnection();
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.VIEWDETAILS);
			ResultSet r=pst.executeQuery();
			StringBuilder s2=new StringBuilder("");
			s2.append("pincode      cabNumber\n");
			while(r.next())
			{
				s2.append(r.getString(1)+"     "+r.getString(2)+"\n");
			}		
			return s2;
		}
		catch(SQLException e)
		{
			logger.error(e.getMessage());
			System.out.println("Tehnical problem occured log");	
		}
		
		
	}

	@Override
	public void addCabRequestDetails(CabRequest r) throws Exception {
		try {
		CabRequest b1=null;;
			Connection conn = com.capgemini.cab.util.DBConnection.getInstance().getConnection();
			
		java.sql.Statement ss=conn.createStatement();
		ResultSet rs=ss.executeQuery(IQueryMapper.CHECKTABLE);
		rs.next();
		String sr=rs.getString(1);
		if(Integer.parseInt(sr)<=0)
			creation();
		java.sql.Statement ss1=conn.createStatement();
		ResultSet rst=ss1.executeQuery(IQueryMapper.GENERTESEQUENCE);
		rst.next();
		int id=rst.getInt(1);
		PreparedStatement pst=conn.prepareStatement(IQueryMapper.GETCABNUMBER);
		pst.setString(1,b1.getCabNumber());
		ResultSet rs1=pst.executeQuery();
		rs1.next();
		int count=Integer.parseInt(rs1.getString(1));
		if(count<=0)
			b1.setStatus("not Accepted");
		else
			b1.setStatus("Accepted");
		PreparedStatement preparestmt=conn.prepareStatement(IQueryMapper.INSERTQUERY);
		b1.setRequestId(id);
		preparestmt.setInt(1,b1.getRequestId());
		preparestmt.setString(2,b1.getCustomerName());
		preparestmt.setString(3,b1.getPhoneNumber());
		preparestmt.setString(4,b1.getDateOfRequest());
		preparestmt.setString(5,b1.getRequestStatus());
		preparestmt.setString(6,b1.getCabNumber());
		preparestmt.setString(7, b1.getAddressOfPickup());
		preparestmt.setString(8,b1.getPincode());
		preparestmt.executeUpdate();
		preparestmt.close();
		pst.close();
		ss.close();
		rst.close();
		conn.close();
		}
		catch(SQLException e)
		{
			logger.error(e.getMessage());
			System.out.println("Error in closing db connection");		
		}
		
	}

	@Override
	public boolean getRequestDetails(int requestId, CabRequest b1) throws Exception {
		
		try {
			CabRequest bean=null;
			Connection con = DBConnection.getInstance().getConnection();
		PreparedStatement pst=con.prepareStatement(IQueryMapper.CHECKREQUESTID);
		pst.setInt(1,requestId);
		ResultSet rs1=pst.executeQuery();
		rs1.next();
		int count=Integer.parseInt(rs1.getString(1));
		if(count<=0)
		{
			System.out.println("invalid request id");
		}
		else
		{
			PreparedStatement ps=con.prepareStatement(IQueryMapper.GETDETAILS);
			ps.setInt(1,requestId);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
		
				bean.setCustomerName(rs.getString(2));
				bean.setRequestStatus(rs.getString(5));
				bean.setCabNumber(rs.getString(6));
				bean.setAddressOfPickup(rs.getString(7));
			}
			ps.close();
			rs.close();
			con.close();
			return false;
		}
		}
		
		catch (SQLException e) 
		{
			logger.error(e.getMessage());
			System.out.println("Error in closing db connection");

		}
		return false;
	}

	@Override
	public String retrieveCabNumber(String pincode) throws Exception{
		//String pincode1=null;
		try {
			Connection conn = DBConnection.getInstance().getConnection();
			PreparedStatement ps=conn.prepareStatement(IQueryMapper.GETPINCODE);
			ps.setString(1,pincode);
		
		ResultSet r=ps.executeQuery();
		while(r.next())
		{
			pincode=r.getString(1);
		}
		
		}catch (SQLException e) 
		{
			logger.error(e.getMessage());
			System.out.println("Error in closing db connection");

		}
		return pincode;
	}
	public void creation() throws Exception
	{
		try {
		Connection conn = DBConnection.getInstance().getConnection();		
		PreparedStatement s=conn.prepareStatement(IQueryMapper.CREATETABLE);
		s.executeUpdate();
		PreparedStatement sn=conn.prepareStatement(IQueryMapper.SEQUENCECREATION);
		sn.executeUpdate();
	}
		catch (SQLException e) 
		{
			logger.error(e.getMessage());
			System.out.println("Error in closing db connection");

		}
	
}


}
