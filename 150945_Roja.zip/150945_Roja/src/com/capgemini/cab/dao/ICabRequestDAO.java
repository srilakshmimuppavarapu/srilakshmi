package com.capgemini.cab.dao;

import com.capgemini.cabs.bean.CabRequest;

public interface ICabRequestDAO {
	StringBuilder displaycabDetails() throws Exception ;
	void addCabRequestDetails(CabRequest r) throws Exception ;
	boolean getRequestDetails(int requestId, CabRequest b1) throws Exception;
	String retrieveCabNumber(String pincode) throws Exception; 

}
