package com.capgemini.cab.dao;

public class IQueryMapper {
	public static final String VIEWDETAILS="SELECT * FROM CabDetails";
	public static final String GETCABNUMBER="SELECT cabNumber FROM CabDetails where pincode=?";
	public static final String CHECKTABLE="SELECT count(*) FROM tab where tname='cab_request'";
	public static final String GENERTESEQUENCE="SELECT seq_request_id.nextval FROM DUAL";
	public static final String GETPINCODE="SELECT count(*) FROM CabDetails where pincode=?";
	public static final String INSERTQUERY="INSERT INTO cab_request VALUES(seq_request_Id.NEXTVAL,?,?,SYSDATE,?,?,?,?)";
	public static final String CHECKREQUESTID="SELECT count(*) FROM cab_request where requestId=?";
	public static final String GETDETAILS="SELECT * FROM cab_request where requestId=?";
	public static final String CREATETABLE="CREATE TABLE cab_request(requestId NUMBER,customerName VARCHAR2(20),phoneNumber VARCHAR2(10),DateOfRequest DATE,requestStatus VARCHAR2(12),cabNumber VARCHAR2(15),addressOfPickup varchar2(50),pincode VARCHAR2(6))";
	public static final String SEQUENCECREATION="CREATE SEQUENCE seq_request_id START WITH 1001  INCREMENT BY 1 NOCYCLE";

}
