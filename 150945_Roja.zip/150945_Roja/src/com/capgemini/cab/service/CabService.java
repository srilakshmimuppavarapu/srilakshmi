package com.capgemini.cab.service;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.cab.dao.*;
import com.capgemini.cabs.bean.CabRequest;
public class CabService implements ICabService {

	@Override
	public StringBuilder displaycabDetails() throws Exception{
		
		ICabRequestDAO i=new CabRequestDAO();
		return i.displaycabDetails();
		
	}

	@Override
	public void addCabRequestDetails(CabRequest r) throws Exception{
		
		ICabRequestDAO rb=new CabRequestDAO();
		rb.addCabRequestDetails(r);
		
	}

	@Override
	public boolean getRequestDetails(int requestId, CabRequest b1) throws Exception{
		
		ICabRequestDAO r=new CabRequestDAO();
		return r.getRequestDetails(requestId,b1);
		
	}

	@Override
	public String retrieveCabNumber(String pincode) throws Exception  {
		
		ICabRequestDAO i=new CabRequestDAO();
		return i.retrieveCabNumber(pincode);
		
		
	}

	@Override
	public boolean isValidcustomerName(String customerName) {
		
		Pattern p=Pattern.compile("[A-Z a-z]{3,}");
		Matcher m=p.matcher(customerName);
		return m.matches();
	}

	@Override
	public boolean isValidMobile(String phoneNumber) {
		
		Pattern p=Pattern.compile("[0-9]{10}");
		Matcher m=p.matcher(phoneNumber);
		return m.matches();
	}

	@Override
	public boolean isValidPincode(CabRequest b1) {
		if(b1.getStatus().equals("Accepted"))
			return true;
		else
		return false;
	}
	

}
