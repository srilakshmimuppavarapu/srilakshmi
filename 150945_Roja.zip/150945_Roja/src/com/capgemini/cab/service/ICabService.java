package com.capgemini.cab.service;


import com.capgemini.cabs.bean.CabRequest;

public interface ICabService {
	StringBuilder displaycabDetails() throws Exception ;
	void addCabRequestDetails(CabRequest r) throws Exception;
	boolean getRequestDetails(int requestId, CabRequest b1) throws Exception ;
	 public String retrieveCabNumber(String pincode) throws Exception; 
	
	public boolean isValidcustomerName(String customerName);
	public boolean isValidPincode( CabRequest b1);
	boolean isValidMobile(String phoneNumber);
}
