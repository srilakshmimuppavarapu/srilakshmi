package com.cg.plp.exception;

public class StudentException extends Exception
{
	private String msg;

	public StudentException(String msg)
	{
			this.msg=msg;
	}
	public String toString()
	{
		return this.msg;
	}
}
