CREATE SEQUENCE registration_seq 
INCREMENT BY 1 
START WITH 1;

CREATE SEQUENCE transaction_seq 
INCREMENT BY 1 
START WITH 101;

CREATE SEQUENCE user_id_seq
INCREMENT BY 1
START WITH 1001;

CREATE TABLE Users(
user_id VARCHAR2(4) PRIMARY KEY,
user_name VARCHAR2(15) NOT NULL,
password VARCHAR2(7) NOT NULL,
email_id VARCHAR2(25),
librarian VARCHAR2(6) NOT NULL);

INSERT INTO Users VALUES(1001,'Harika','abc123','ht@cg','false');
INSERT INTO Users VALUES(1002,'lib','lib','ht@cg','true');

CREATE TABLE BooksInventory(
book_id VARCHAR2(4) PRIMARY KEY,
book_name VARCHAR2(20) NOT NULL,
author1 VARCHAR2(15) NOT NULL,
author2 VARCHAR2(15),
publisher VARCHAR2(20),
yearofpublication VARCHAR2(4),
no_of_copies NUMBER(5) NOT NULL);

INSERT INTO BooksInventory VALUES('101','Let Us C++','Yashavant','B.C. Desai','H.Schild',2000,3);
INSERT INTO BooksInventory VALUES('102','Master VC++','P.J Allen','Yashavant','B.C. Desai',2005,4);
INSERT INTO BooksInventory VALUES('103','JAVA Reference','H.Schild','Yashavant','B.C. Desai',2004,0);
INSERT INTO BooksInventory VALUES('104','J2EE Reference','Yashavant','H.Schild','B.C. Desai',2000,1);
INSERT INTO BooksInventory VALUES('105','Relational DBMS','B.C. Desai','Yashavant','H.Schild',2000,6);

CREATE TABLE BooksRegistration(
registration_id VARCHAR2(4) PRIMARY KEY,
book_id VARCHAR2(4) REFERENCES BooksInventory(book_id),
user_id VARCHAR2(4) REFERENCES Users(user_id),
registrationdate DATE DEFAULT SYSDATE,
status VARCHAR2(6) DEFAULT 'false');

CREATE TABLE BooksTransaction(
transaction_id VARCHAR2(4) PRIMARY KEY, 
registration_id VARCHAR2(4),
issue_date DATE DEFAULT SYSDATE,
return_date DATE,
fine NUMBER(3) DEFAULT -1);




CREATE TABLE BooksRegHistory(
registration_id VARCHAR2(4),
book_id VARCHAR2(4) REFERENCES BooksInventory(book_id),
user_id VARCHAR2(4) REFERENCES Users(user_id),
registrationdate DATE DEFAULT SYSDATE);
