package com.author.recharge.test;
import java.sql.SQLException;

import com.author.recharge.bean.*;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.author.recharge.bean.RechargeBean;
import com.author.recharge.dao.RechargeDaoImpl;
import com.author.recharge.exception.InvalidRecharge;

public class RechargeDaoTest{
	static RechargeDaoImpl rech=null;
	static RechargeBean rb=null;
	
	@BeforeClass
	public static void Initialize()
	{
		rech=new RechargeDaoImpl();
		rb=new RechargeBean();
	}
	
	@Ignore
	@Test
	public void testAddUserDetails() throws InvalidRecharge {
		rb.setUserName("asva");
		rb.setUserMobileNum("9998887772");
		rb.setPlanName("Rc150");
		int amount=rech.retrieveAmount("Rc150");
		rb.setAmount(amount);
		rech.addUserDetails(rb);
		System.out.println(rb.getRechId());
		assertEquals(1000053, rb.getRechId());
		
	}
	@Test
	public void testAddUserDetails1() throws InvalidRecharge
	{
		rb.setUserName("sri");
		rb.setUserMobileNum("9848022338");
		rb.setPlanName("Rc150");
		int amount=rech.retrieveAmount("Rc150");
		rb.setAmount(amount);
		rech.addUserDetails(rb);
		assertEquals("Success",rb.getStatus());
	}
	@Test
	public void testRetrieveUserDetails() throws InvalidRecharge
	{
		assertSame(false,rech.retrieveUserDetails("1000002",rb));
}
	
	@Test
	public void testRetrieveUserDetails1() throws InvalidRecharge
	{
		assertSame(true,rech.retrieveUserDetails("10000091",rb));
	}
	
	
}
