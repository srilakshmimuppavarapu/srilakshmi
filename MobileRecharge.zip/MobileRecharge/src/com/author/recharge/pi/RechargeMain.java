package com.author.recharge.pi;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

//import java.util.logging.Logger;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.author.recharge.bean.RechargeBean;
import com.author.recharge.exception.InvalidRecharge;
import com.author.recharge.service.IRechargeService;
import com.author.recharge.service.RechargeServiceImpl;

public class RechargeMain 
{
	static Logger logger=Logger.getRootLogger();
	
	public static void main(String args[])  throws SQLException
	{	
		try 
		{
			boolean retry=false;
			String mobileNum,name;
		
			IRechargeService s1=new RechargeServiceImpl();
			RechargeBean b1=new RechargeBean();
			Scanner sc=new Scanner(System.in);
		
			do
			{
				System.out.println("enter username :");
				name=sc.next();
			}while(!s1.isValidName(name));
			b1.setUserName(name);
			
			do
			{	
				System.out.println("enter mobile number :");
				mobileNum=sc.next();
			}while(!s1.isValidMobile(mobileNum));
			b1.setUserMobileNum(mobileNum);
			
			System.out.println("enter plan from below :");
			System.out.println(s1.displayPlans());
			
			System.out.println("enter Plan Name :");
			String planName=sc.next();
			
			b1.setPlanName(planName);
			
			s1.retrieveAmount(planName);
			b1.setAmount(s1.retrieveAmount(planName));
			s1.addUserDetails(b1);
			System.out.println(b1.getStatus());
			
			if(s1.isValidRecharge(b1))
			{
				System.out.println("your mobile has been recharged...rech id is <"+b1.getRechId()+">");
				logger.info("Recharge Successful");
			}
			else
			{
				System.out.println("Your rech id is <"+b1.getRechId()+"> Check your status");
			}
			do
			{
				retry=false;
				System.out.println("1. continue the process by giving the transaction id to get details");
				System.out.println("2.exit");
				System.out.println("Enter your choice");
				int num=sc.nextInt();
				if(num==1)
				{
					retry=true;
					System.out.println("Enter your recharge Id :");
					String rech=sc.next();
					retry=s1.retrieveUserDetails(rech,b1);
					//System.out.println(b1);
					
				}
				else
				{
					System.out.println("Thank you");
					System.exit(0);
				}
			}while(!retry);
			
			
//			System.out.println("1. continue the process by giving the transaction id to get details");
//			String rech=sc.next();
//			retry=s1.retrieveUserDetails(rech,b1);
		}
		catch(InputMismatchException e)
		{
			logger.error("Exception Occured"+e);
			System.out.println(e);
		}
		catch(ClassCastException ce)
		{
			logger.error("Exception Occured"+ce);
			System.out.println(ce);
		}
		catch(NullPointerException npe)
		{
			logger.error("Exception Occured"+npe);
			System.out.println(npe);
		}
		catch(InvalidRecharge ir)
		{
			logger.error("Exception Occured"+ir);
			System.out.println(ir);
		}
	}
}
