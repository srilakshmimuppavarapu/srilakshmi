LAB 3.1 joins and sub-queries
-----------------------------

1. Write a query which displays Staff Name, Department Code, Department Name,
and Salary for all staff who earns more than 20000.

---

SQL> SELECT staff_name,department_master.dept_code,dept_name, staff_sal
  2  FROM staff_master,department_master
  3  WHERE staff_master.dept_code=department_master.dept_code
  4  AND staff_sal > 20000;

STAFF_NAME                                          DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME                                           STAFF_SAL
-------------------------------------------------- ----------
John                                                       10
Information Technology                                  32000

Mohan                                                      10
Information Technology                                  24000

Rahul                                                      20
Electricals                                             22000


STAFF_NAME                                          DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME                                           STAFF_SAL
-------------------------------------------------- ----------
Smith                                                      20
Electricals                                             62000

Ram                                                        30
Electronics                                             32000

Allen                                                      30
Electronics                                             42000


6 rows selected.



2. Display Staff Code, Staff Name, Department Name, and his manager’s number
and name. Label the columns Staff#, Staff, Mgr#, Manager.

---
SQL>  SELECT staff.staff_code AS "Staff#",staff.staff_name AS "Staff",dept_name,
  2   mgr.staff_code AS "Mgr#", mgr.staff_name AS "Manager"
  3   FROM staff_master staff,staff_master mgr,department_master
  4   WHERE staff.mgr_code=mgr.staff_code AND
  5   staff.dept_code=department_master.dept_code;

    Staff# Staff
---------- --------------------------------------------------
DEPT_NAME                                                Mgr#
-------------------------------------------------- ----------
Manager
--------------------------------------------------
    100006 Allen
Electronics                                            100005
John

    100007 Smith
Electricals                                            100005
John

    Staff# Staff
---------- --------------------------------------------------
DEPT_NAME                                                Mgr#
-------------------------------------------------- ----------
Manager
--------------------------------------------------

    100008 Raviraj
Mechanics                                              100006
Allen

    100001 Arvind
Electronics                                            100006

    Staff# Staff
---------- --------------------------------------------------
DEPT_NAME                                                Mgr#
-------------------------------------------------- ----------
Manager
--------------------------------------------------
Allen

    100004 Anil
Electricals                                            100006
Allen

    100009 Rahul

    Staff# Staff
---------- --------------------------------------------------
DEPT_NAME                                                Mgr#
-------------------------------------------------- ----------
Manager
--------------------------------------------------
Electricals                                            100006
Allen

    100003 Mohan
Information Technology                                 100006
Allen


    Staff# Staff
---------- --------------------------------------------------
DEPT_NAME                                                Mgr#
-------------------------------------------------- ----------
Manager
--------------------------------------------------
    100010 Ram
Electronics                                            100007
Smith

    100002 Shyam
Electricals                                            100007
Smith

    Staff# Staff
---------- --------------------------------------------------
DEPT_NAME                                                Mgr#
-------------------------------------------------- ----------
Manager
--------------------------------------------------

    100005 John
Information Technology                                 100007
Smith


10 rows selected.


 
 
 3. Create a query that will display Student Code, Student Name, Book Code, and
Book Name for all students whose expected book return date is today.
---
SQL> SELECT stu.student_code,stu.student_name,book_master.book_code,book_master.
book_name
  2  FROM student_master stu,book_master,book_transactions
  3  WHERE stu.student_code=book_transactions.student_code
  4  AND book_transactions.book_code=book_master.book_code
  5  AND book_expected_return_date=sysdate;

no rows selected


4. Create a query that will display Staff Code, Staff Name, Department Name,
Designation name, Book Code, Book Name, and Issue Date for only those staff
who have taken any book in last 30 days. . If required, make changes to the table
to create such a scenario.

---
SQL> SELECT staff.staff_code,
  2  staff.staff_name,
  3  dept.dept_name,
  4  desig.design_name,
  5  book.book_code,
  6  book.book_name
  7  FROM staff_master staff,department_master dept,designation_master desig,
  8  book_master book,book_transactions bk_tran
  9  WHERE
 10  staff.dept_code=dept.dept_code AND
 11  staff.design_code=desig.design_code AND
 12  bk_tran.staff_code=staff.staff_code AND
 13  bk_tran.book_code=book.book_code AND
 14  book_issue_date BETWEEN SYSDATE-30 AND SYSDATE;

STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DEPT_NAME
--------------------------------------------------
DESIGN_NAME                                         BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
    100006 Allen
Electronics
Reader                                               10000008
Computer Networks


5. Generate a report which contains the following information.
Staff Code, Staff Name, Designation Name, Department, Book Code, Book
Name,
Author, Fine For the staff who has not returned the book. Fine will be calculated
as Rs. 5 per day.
Fine = 5 * (No. of days = Current Date – Expected return date). Include records in
the table to suit this problem statement
---

SQL> SELECT
  2  staff.staff_code,
  3  staff.staff_name,
  4  desig.design_name,
  5  dept.dept_code,
  6  dept.dept_name,
  7  book.book_code,
  8  book.book_name,
  9  book.book_pub_author,
 10  (5* (sysdate - book_expected_return_date)) AS "Fine"
 11  FROM
 12  staff_master staff,designation_master desig,
 13  department_master dept,book_master book,
 14  book_transactions bk_trans
 15  WHERE
 16  staff.dept_code=dept.dept_code AND
 17  staff.design_code=desig.design_code AND
 18  bk_trans.staff_code=staff.staff_code AND
 19  bk_trans.book_code=book.book_code;

STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME                                         DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          Fine
-------------------------------------------------- ----------
    100007 Smith
Reader                                                     20
Electricals                                          10000005

STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME                                         DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          Fine
-------------------------------------------------- ----------
Relational DBMS
B.C. Desai                                         13133.1441


STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME                                         DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          Fine
-------------------------------------------------- ----------
    100007 Smith
Reader                                                     20
Electricals                                          10000007

STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME                                         DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          Fine
-------------------------------------------------- ----------
Intoduction To Algorithams
Cormen                                             13048.1441


STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME                                         DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          Fine
-------------------------------------------------- ----------
    100006 Allen
Reader                                                     30
Electronics                                          10000007

STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME                                         DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          Fine
-------------------------------------------------- ----------
Intoduction To Algorithams
Cormen                                             14873.1441


STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME                                         DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          Fine
-------------------------------------------------- ----------
    100006 Allen
Reader                                                     30
Electronics                                          10000008

STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME                                         DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          Fine
-------------------------------------------------- ----------
Computer Networks
Tanenbaum                                          13153.1441


STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME                                         DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          Fine
-------------------------------------------------- ----------
    100006 Allen
Reader                                                     30
Electronics                                          10000008

STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME                                         DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          Fine
-------------------------------------------------- ----------
Computer Networks
Tanenbaum                                          13088.1441


STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME                                         DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          Fine
-------------------------------------------------- ----------
    100006 Allen
Reader                                                     30
Electronics                                          10000008

STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME                                         DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          Fine
-------------------------------------------------- ----------
Computer Networks
Tanenbaum                                          -1.8559028


STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME                                         DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          Fine
-------------------------------------------------- ----------
    100010 Ram
Reader                                                     30
Electronics                                          10000009

STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME                                         DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          Fine
-------------------------------------------------- ----------
Introduction to O/S
Millan                                             13043.1441


7 rows selected.




6. List Staff Code, Staff Name, and Salary for those who are getting less than the
average salary of organization.  

---
SQL> SELECT staff_code,staff_name,staff_sal
  2  FROM staff_master
  3  WHERE staff_sal < (SELECT AVG(staff_sal) FROM staff_master);

STAFF_CODE STAFF_NAME                                          STAFF_SAL
---------- -------------------------------------------------- ----------
    100001 Arvind                                                  17000
    100002 Shyam                                                   20000
    100003 Mohan                                                   24000
    100004 Anil                                                    20000
    100008 Raviraj                                                 18000
    100009 Rahul                                                   22000

6 rows selected.




7. Display Author Name, Book Name for those authors who wrote more than one
book.

---
SQL> SELECT book_pub_author,book_name
  2  FROM book_master b
  3  WHERE
  4  (SELECT count(book_name) FROM book_master m
  5  WHERE m.book_pub_author=b.book_pub_author) > 1;

BOOK_PUB_AUTHOR
--------------------------------------------------
BOOK_NAME
--------------------------------------------------
Yashavant Kanetkar
Let Us C++

Yashavant Kanetkar
Let Us C


8. Display Staff Code, Staff Name, and Department Name for those who have taken
more than one book.

---
SQL> SELECT staff_code,staff_name,dept_name
  2  FROM staff_master,department_master
  3  WHERE staff_master.dept_code=department_master.dept_code
  4  AND
  5  (SELECT count(book_code) FROM book_transactions bt
  6  WHERE
  7  bt.staff_code=staff_master.staff_code) > 1;

STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DEPT_NAME
--------------------------------------------------
    100007 Smith
Electricals

    100006 Allen
Electronics


9. Display the Student Code, Student Name, and Department Name for that
department in which there are maximum number of student studying.



10. Display Staff Code, Staff Name, Department Name, and Designation name for
those who have joined in last 3 months.

---
SQL> SELECT s.staff_code,s.staff_name,d.dept_name,desig.design_name
  2  FROM staff_master s,department_master d,designation_master desig
  3  WHERE
  4  s.dept_code=d.dept_code
  5  AND
  6  s.design_code=desig.design_code
  7  AND months_between(sysdate,hiredate)<=3;

no rows selected
