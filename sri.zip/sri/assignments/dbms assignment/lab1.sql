SQL> create table emp (Empno number(4) not null,
  2  Ename varchar2(10),
  3  job varchar2(9),
  4  mgr number(4),
  5  Hiredate date,
  6  Sal number(7,2),
  7  Comm number(7,2),
  8  Deptno number(2));

Table created.


SQL> create table Designation_Master (
  2  Design_code number(3) not null,
  3  Design_name varchar2(50));

Table created.



SQL> create table Department_Master (Dept_Code number(2) not null,
  2  Dept_name varchar2(50));

Table created.


SQL> create table Student_Master (Student_Code number(6) not null,
  2  Student_name varchar2(50) not null,
  3  Dept_Code number(2),
  4  Student_dob Date,
  5  Student_Address varchar2(240));

Table created.



SQL> CREATE table Student_Marks (Student_Code number(8),
  2  Student_Year number not null,
  3  Subject1 number(3),
  4  Subject2 number(3),
  5  Subject3 number(3));

Table created.



SQL> CREATE table Student_Marks (Student_Code number(8),
  2  Student_Year number not null,
  3  Subject1 number(3),
  4  Subject2 number(3),
  5  Subject3 number(3));

Table created.



SQL> create table Book_Master (Book_Code number(10) not null,
  2  Book_Name varchar2(50) not null,
  3  Book_pub_year number,
  4  Book_pub_author varchar2(50) not null);

Table created.



SQL> CREATE TABLE Book_Transactions (Book_Code number,
  2  Student_code number,
  3  Staff_code number,
  4  Book_Issue_date date not null,
  5  Book_expected_return_date date not null,
  6  Book_actual_return_date Date);

Table created.


lab 1.1
-------

1. List the Name and Designation code of the staff who have joined before Jan 2003
and whose salary range is between 12000 and 25000. Display the columns with
user defined Column headers. Hint: Use As clause along with other operators

---
SQL> SELECT staff_name AS name, design_code AS designation from Staff_master
  2  WHERE hiredate < '01-jan-2003' AND
  3  staff_sal between 12000 and 25000;

NAME                                               DESIGNATION
-------------------------------------------------- -----------
Shyam                                                      102
Mohan                                                      102
Anil                                                       102


2. List the staff code, name, and department number of the staff who have
experience of 18 or more years and sort them based on their experience.

---
SQL> SELECT staff_code,staff_name,dept_code
  2  FROM staff_master
  3  WHERE months_between(hiredate,sysdate)>=216;

no rows selected



3. Display the staff details who do not have manager. Hint: Use is null

---
SQL> SELECT staff_code,staff_name, design_code, dept_code,hiredate,staff_dob, st
aff_address,mgr_code,staff_sal
  2  FROM staff_master
  3  WHERE mgr_code is null;

no rows selected


4. Display the Book details that were published during the period of 2001 to 2004.
Also display book details with Book name having the character ‘&’ anywhere.

---
SQL> SELECT book_code,book_name,book_pub_year,book_pub_author
  2  FROM book_master
  3  where book_pub_year BETWEEN 2001 AND 2004
  4  AND book_name LIKE '%&%';

no rows selected


5. List the names of the staff having ‘_’ character in their name.

---


SQL> SELECT staff_name
  2  FROM staff_master
  3  WHERE staff_name LIKE '%/_%' ESCAPE '/';

no rows selected

/*
SQL> SELECT staff_name
  2  FROM staff_master
  3  WHERE staff_name LIKE '%\_%' ESCAPE '\';

STAFF_NAME
--------------------------------------------------
sri_m

SQL> SELECT staff_name
  2  FROM staff_master
  3  WHERE staff_name LIKE '%/_%' ESCAPE '/';

STAFF_NAME
--------------------------------------------------
sri_m
*/











						   























































