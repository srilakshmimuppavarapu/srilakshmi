6.1: Transaction Control Language Statements


1. Insert rows with the following data into the Customer table. 6000, John, #115
Chicago, #115 Chicago, M, 25, 7878776, 10000
 6001, Jack, #116 France, #116 France, M, 25, 434524, 20000
 6002, James, #114 New York, #114 New York, M, 45, 431525, 15000.50
Use parameter substitution.


SQL> INSERT INTO cust_table VALUES (&id,'&name','&addr1','&addr2','&gender',&age
,&phoneno);
Enter value for id: 6000
Enter value for name: John
Enter value for addr1: #115 chicago
Enter value for addr2: #115 chicago
Enter value for gender: M
Enter value for age: 25
Enter value for phoneno: 7878776
old   1: INSERT INTO cust_table VALUES (&id,'&name','&addr1','&addr2','&gender',
&age,&phoneno)
new   1: INSERT INTO cust_table VALUES (6000,'John','#115 chicago','#115 chicago
','M',25,7878776)

1 row created.

SQL> INSERT INTO cust_table VALUES (&id,'&name','&addr1','&addr2','&gender',&age
,&phoneno);
Enter value for id: 6001
Enter value for name: Jack
Enter value for addr1: #116 France
Enter value for addr2: #116 France
Enter value for gender: M
Enter value for age: 25
Enter value for phoneno: 434524
old   1: INSERT INTO cust_table VALUES (&id,'&name','&addr1','&addr2','&gender',
&age,&phoneno)
new   1: INSERT INTO cust_table VALUES (6001,'Jack','#116 France','#116 France',
'M',25,434524)

1 row created.

SQL> INSERT INTO cust_table VALUES (&id,'&name','&addr1','&addr2','&gender',&age
,&phoneno);
Enter value for id: 6002
Enter value for name: James
Enter value for addr1: #114 New York
Enter value for addr2: #114 New York
Enter value for gender: M
Enter value for age: 45
Enter value for phoneno: 431525
old   1: INSERT INTO cust_table VALUES (&id,'&name','&addr1','&addr2','&gender',
&age,&phoneno)
new   1: INSERT INTO cust_table VALUES (6002,'James','#114 New York','#114 New Y
ork','M',45,431525)

1 row created.





2. Create a Savepoint named ‘SP1’ after third record in the Customer table .

SQL> savepoint sp1;

Savepoint created.



3. Insert the below row in the Customer table.
6003, John, #114 Chicago, #114 Chicago, M, 45, 439525, 19000.60


SQL> INSERT INTO cust_table VALUES (&id,'&name','&addr1','&addr2','&gender',&age
,&phoneno);
Enter value for id: 6003
Enter value for name: John
Enter value for addr1: #114 Chicago
Enter value for addr2: #114 Chicago
Enter value for gender: M
Enter value for age: 45
Enter value for phoneno: 439525
old   1: INSERT INTO cust_table VALUES (&id,'&name','&addr1','&addr2','&gender',
&age,&phoneno)
new   1: INSERT INTO cust_table VALUES (6003,'John','#114 Chicago','#114 Chicago
','M',45,439525)

1 row created.



4. Execute rollback statement in such a way that whatever manipulations done
before Savepoint sp1 are permanently implemented, and the ones after
Savepoint SP1 are not stored as a part of the Customer table.


SQL> rollback to sp1;

Rollback complete.

SQL> commit;

Commit complete.
