LAB 2.2
-------

1. Display the Highest, Lowest, Total & Average salary of all staff. Label the
columns Maximum, Minimum, Total and Average respectively for each
Department code. Also round the result to the nearest whole number.

---
SQL> SELECT MAX(staff_sal) AS "Maximum",MIN(staff_sal) AS "Minimum",
  2  SUM(staff_sal) AS "Total",ROUND(AVG(staff_sal)) AS "Average"
  3  FROM staff_master
  4  GROUP BY dept_code;

   Maximum    Minimum      Total    Average
---------- ---------- ---------- ----------
     42000      17000      91000      30333
     62000      20000     124000      31000
     18000      18000      18000      18000
     32000      24000      56000      28000

	 
2. Display Department code and number of managers working in that department.
Label the column as ‘Total Number of Managers’ for each department.

---
SQL> SELECT dept_code,count(mgr_code) AS "Total Number of Managers"
  2  FROM staff_master
  3  GROUP BY dept_code;

 DEPT_CODE Total Number of Managers
---------- ------------------------
        30                        3
        20                        4
        40                        1
        10                        2

3. Get the Department number, and sum of Salary of all non-managers where the
sum is greater than 20000.

---
SQL> SELECT dept_code,SUM(staff_sal)
  2  FROM staff_master
  3  WHERE mgr_code IS NULL
  4  GROUP BY dept_code
  5  HAVING SUM(staff_sal)>20000;

no rows selected
