LAB 2.1
-------

1. Create a query which will display Staff Name, Salary of each staff. Format the
salary to be 15 characters long and left padded with ‘$’.

---

SQL> SELECT staff_name,lpad(staff_sal,15,'$')
  2  FROM staff_master;

STAFF_NAME                                         LPAD(STAFF_SAL,
-------------------------------------------------- ---------------
Arvind                                             $$$$$$$$$$17000
Shyam                                              $$$$$$$$$$20000
Mohan                                              $$$$$$$$$$24000
Anil                                               $$$$$$$$$$20000
John                                               $$$$$$$$$$32000
Allen                                              $$$$$$$$$$42000
Smith                                              $$$$$$$$$$62000
Raviraj                                            $$$$$$$$$$18000
Rahul                                              $$$$$$$$$$22000
Ram                                                $$$$$$$$$$32000

10 rows selected.


2. Display name and date of birth of students where date of birth must be displayed
in the format similar to “January, 12 1981” for those who were born on Saturday
or Sunday.

---
SQL> SELECT student_name,TO_CHAR(student_dob,'month, dd yyyy')
  2  FROM student_master
  3  WHERE TO_CHAR(student_dob,'day') LIKE 'sat%' OR
  4  TO_CHAR(student_dob,'day') LIKE 'sun%';

STUDENT_NAME                                       TO_CHAR(STUDENT_DO
-------------------------------------------------- ------------------
Ravi                                               november , 01 1981
Raj                                                january  , 14 1979
Arvind                                             january  , 15 1983
Mehul                                              january  , 17 1982
Vijay                                              january  , 19 1980
Rajat                                              january  , 20 1980
Ramesh                                             december , 27 1980
Amit Raj                                           september, 28 1980

8 rows selected.


3. Display each Staff name and number of months they worked for the organization.
Label the column as ‘Months Worked’. Order your result by number of months
employed. Also Round the number of months to closest whole number.

---
SQL> SELECT staff_name,ROUND(MONTHS_BETWEEN(SYSDATE,hiredate)) AS "MONTHS WORKED
"
  2  FROM staff_master
  3  ORDER BY 2;

STAFF_NAME                                         MONTHS WORKED
-------------------------------------------------- -------------
Rahul                                                        174
Arvind                                                       184
Raviraj                                                      185
Smith                                                        195
Shyam                                                        195
Mohan                                                        196
Ram                                                          196
Allen                                                        205
Anil                                                         207
John                                                         208

10 rows selected.

4. List the details of the staff who have joined in first half of December month
(irrespective of the year).

---

SQL> SELECT staff_code,staff_name,design_code,dept_code,hiredate,staff_dob,staf
_address,mgr_code,staff_sal
  2  FROM staff_master
  3  WHERE
  4  to_char(hiredate,'dd') <=15 AND to_char(hiredate,'mon')='dec';

STAFF_CODE STAFF_NAME                                         DESIGN_CODE
---------- -------------------------------------------------- -----------
 DEPT_CODE HIREDATE  STAFF_DOB
---------- --------- ---------
STAFF_ADDRESS
-------------------------------------------------------------------------------

  MGR_CODE  STAFF_SAL
---------- ----------
    100009 Rahul                                                      102
        20 11-DEC-03 16-JAN-78
Hyderabad
    100006      22000


	
5.  Write a query that displays Staff Name, Salary, and Grade of all staff. Grade
	depends on the following table.
	Salary 						Grade
	Salary >=50000 				A
	Salary >= 25000 < 50000 	B
	Salary>=10000 < 25000 		C
	OTHERS 						D

---
SQL> SELECT staff_name,staff_sal,
  2  CASE
  3  WHEN staff_sal >= 50000 THEN 'A'
  4  WHEN staff_sal >= 25000 AND staff_sal<50000 THEN 'B'
  5  WHEN staff_sal >= 10000 AND staff_sal<25000 THEN 'C'
  6  ELSE 'D'
  7  END AS grade
  8  FROM staff_master;

STAFF_NAME                                          STAFF_SAL G
-------------------------------------------------- ---------- -
Arvind                                                  17000 C
Shyam                                                   20000 C
Mohan                                                   24000 C
Anil                                                    20000 C
John                                                    32000 B
Allen                                                   42000 B
Smith                                                   62000 A
Raviraj                                                 18000 C
Rahul                                                   22000 C
Ram                                                     32000 B

10 rows selected.


6. Display the Staff Name, Hire date and day of the week on which staff was hired.
Label the column as DAY. Order the result by the day of the week starting with
Monday. Hint :Use to_char with hiredate and formats ‘DY’ and ’D’

---
SQL> SELECT staff_name,hiredate,to_char(hiredate,'day') AS "DAY"
  2  FROM staff_master
  3  ORDER BY hiredate-NEXT_DAY(hiredate,'monday');

STAFF_NAME                                         HIREDATE  DAY
-------------------------------------------------- --------- ---------
Allen                                              23-APR-01 monday
Smith                                              12-MAR-02 tuesday
Arvind                                             15-JAN-03 wednesday
Rahul                                              11-DEC-03 thursday
Ram                                                17-JAN-02 thursday
Raviraj                                            11-JAN-03 saturday
Mohan                                              19-JAN-02 saturday
Anil                                               11-MAR-01 sunday
Shyam                                              17-FEB-02 sunday
John                                               21-JAN-01 sunday

10 rows selected.


7. Write a query to find the position of third occurrence of ‘i’ in the given word
‘Mississippi’.

---
SQL> SELECT INSTR('Mississippi','i',1,3) FROM DUAL;

	INSTR('MISSISSIPPI','I',1,3)
	----------------------------
                           8
						   

8. Write a query to find the pay date for the month. Pay date is the last Friday of the
month. Display the date in the format “Twenty Eighth of January, 2002”. Label the
heading as PAY DATE. Hint: use to_char, next_day and last_day functions.
						   
---
SQL> SELECT to_char(NEXT_DAY(LAST_DAY(SYSDATE)-7,'FRIDAY'),'DDSPth "of" mon yyyy
') AS "PAY DATE"
  2  FROM DUAL;

PAY DATE
--------------------------
TWENTY-FIFTH of may 2018

						   
9. Display Student code, Name and Dept Name. Display “Electricals” if dept code 
	=20, “Electronics” if Dept code =30 and “Others” for all other Dept codes in the
Dept Name column. Hint : Use Decode						   
						   
---

SQL> SELECT student_code,student_name,dept_code,
  2  DECODE(dept_code,20,'ELECTRICALS',30,'ELECTRONICS','OTHERS')
  3  FROM student_master;

STUDENT_CODE STUDENT_NAME                                        DEPT_CODE
------------ -------------------------------------------------- ----------
DECODE(DEPT
-----------
        1001 Amit                                                       10
OTHERS

        1002 Ravi                                                       10
OTHERS

        1003 Ajay                                                       20
ELECTRICALS


STUDENT_CODE STUDENT_NAME                                        DEPT_CODE
------------ -------------------------------------------------- ----------
DECODE(DEPT
-----------
        1004 Raj                                                        30
ELECTRONICS

        1005 Arvind                                                     40
OTHERS

        1006 Rahul                                                      50
OTHERS


STUDENT_CODE STUDENT_NAME                                        DEPT_CODE
------------ -------------------------------------------------- ----------
DECODE(DEPT
-----------
        1007 Mehul                                                      20
ELECTRICALS

        1008 Dev                                                        10
OTHERS

        1009 Vijay                                                      30
ELECTRONICS


STUDENT_CODE STUDENT_NAME                                        DEPT_CODE
------------ -------------------------------------------------- ----------
DECODE(DEPT
-----------
        1010 Rajat                                                      40
OTHERS

        1011 Sunder                                                     50
OTHERS

        1012 Rajesh                                                     30
ELECTRONICS


STUDENT_CODE STUDENT_NAME                                        DEPT_CODE
------------ -------------------------------------------------- ----------
DECODE(DEPT
-----------
        1013 Anil                                                       20
ELECTRICALS

        1014 Sunil                                                      10
OTHERS

        1015 Kapil                                                      40
OTHERS


STUDENT_CODE STUDENT_NAME                                        DEPT_CODE
------------ -------------------------------------------------- ----------
DECODE(DEPT
-----------
        1016 Ashok                                                      40
OTHERS

        1017 Ramesh                                                     30
ELECTRONICS

        1018 Amit Raj                                                   50
OTHERS


STUDENT_CODE STUDENT_NAME                                        DEPT_CODE
------------ -------------------------------------------------- ----------
DECODE(DEPT
-----------
        1019 Ravi Raj                                                   50
OTHERS

        1020 Amrit                                                      10
OTHERS

        1021 Sumit                                                      20
ELECTRICALS


21 rows selected.
