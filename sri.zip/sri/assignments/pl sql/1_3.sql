DECLARE
	emp_details emp%rowtype;
BEGIN
	SELECT * INTO emp_details FROM emp WHERE empno=&emp_no;
	DBMS_OUTPUT.PUT_LINE(emp_details.empno||' '||emp_details.ename||' '||emp_details.job||' '||emp_details.mgr||' '||emp_details.hiredate||' '||emp_details.sal||' '||emp_details.comm||' '||emp_details.deptno);
END;
/


SQL> /
Enter value for emp_no: 7369
old   4:        SELECT * INTO emp_details FROM emp WHERE empno=&emp_no;
new   4:        SELECT * INTO emp_details FROM emp WHERE empno=7369;
7369 SMITH CLERK 7902 17-DEC-80 800  20

PL/SQL procedure successfully completed.