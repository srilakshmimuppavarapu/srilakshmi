DECLARE
NullValueException EXCEPTION;
TYPE EmpRec IS RECORD(
v_empno emp.empno%TYPE,v_ename emp.ename%TYPE,v_sal emp.sal%TYPE,
v_comm emp.comm%TYPE);
v_emprec EmpRec;
BEGIN
	SELECT emp.empno,emp.ename,emp.sal,emp.comm INTO v_emprec.v_empno,v_emprec.v_ename,
	v_emprec.v_sal,v_emprec.v_sal FROM emp
WHERE 
emp.empno='&empno';
DBMS_OUTPUT.PUT_LINE(v_emprec.v_empno||' '||v_emprec.v_ename||' '||
v_emprec.v_sal||' '||v_emprec.v_comm);
if v_comm IS NULL THEN
	raise NullValueException;
END if;
EXCEPTION
WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('NO DATA FOUND');
		
WHEN NullValueException THEN
	DBMS_OUTPUT.PUT_LINE('NULL values are present');
END;
	
 /
 
 