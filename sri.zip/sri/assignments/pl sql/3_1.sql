CREATE OR REPLACE FUNCTION calculate_age(emp_age date) RETURN number AS
 age number;
 BEGIN
    age:=months_between(sysdate,emp_age);
    age:=age/12;
    age:=round(age);
    return age;
 END;
 /

 
Function created.



SQL> SELECT calculate_age('09-apr-1997') FROM DUAL;

CALCULATE_AGE('09-APR-1997')
----------------------------
                          21