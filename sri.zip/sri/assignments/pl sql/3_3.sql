
SQL> CREATE OR REPLACE FUNCTION Calculate_sal(staff_id NUMBER) RETURN NUMBER AS
  2  C_DA NUMBER:=0.15;
  3  C_HRA NUMBER:=0.2;
  4  v_sal NUMBER:=0;
  5  C_TA NUMBER:=0.08;
  6  C_SA NUMBER:=0;
  7  v_exp NUMBER:=0;
  8  BEGIN
  9  SELECT staff_sal,MONTHS_BETWEEN(SYSDATE,staff_master.hiredate) INTO v_sal,v
_exp FROM staff_master WHERE staff_code=staff_id;
 10    IF v_exp < 12 THEN
 11    v_sal:=v_sal+(C_DA*v_sal)+(C_HRA*v_sal)+(C_TA*v_sal);
 12    RETURN v_sal;
 13    ELSIF v_exp >= 12 AND v_exp < 24 THEN
 14    C_SA:=0.1*v_sal;
 15    v_sal:=v_sal+(C_DA*v_sal)+(C_HRA*v_sal)+(C_TA*v_sal)+C_SA;
 16    RETURN v_sal;
 17    ELSIF v_exp >= 24 AND v_exp < 48 THEN
 18       C_SA:=0.2*v_sal;
 19       v_sal:=v_sal+(C_DA*v_sal)+(C_HRA*v_sal)+(C_TA*v_sal)+C_SA;
 20       RETURN v_sal;
 21    ELSE
 22       C_SA:=0.3*v_sal;
 23      v_sal:=v_sal+(C_DA*v_sal)+(C_HRA*v_sal)+(C_TA*v_sal)+C_SA;
 24       RETURN v_sal;
 25    END IF;
 26  END Calculate_sal;
 27  /

Function created.



SQL> SELECT Calculate_sal(100001) FROM DUAL;

CALCULATE_SAL(100001)
---------------------
              80012.5
