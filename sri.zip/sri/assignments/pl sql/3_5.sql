CREATE OR REPLACE PROCEDURE book_details(book_id NUMBER,student_id NUMBER,staff_id NUMBER) AS
v_book_issue_date DATE;
v_book_expected_date DATE;
BEGIN
v_book_issue_date:=SYSDATE;
v_book_expected_date:=SYSDATE+10;
DBMS_OUTPUT.PUT_LINE(v_book_expected_date);
IF TO_CHAR(v_book_expected_date,'DY')='SAT' THEN
	v_book_expected_date:=NEXT_DAY(v_book_expected_date,'Monday');
ELSIF TO_CHAR(v_book_expected_date,'DY')='SUN' THEN
	v_book_expected_date:=NEXT_DAY(v_book_expected_date,'Monday');
END IF;
INSERT INTO book_transactions VALUES(book_id,student_id,staff_id,v_book_issue_date,v_book_expected_date,NULL);
END book_details;
/



Procedure created.

SQL> EXECUTE book_details(10002,NULL,103);
09-JUN-18

PL/SQL procedure successfully completed.

SQL> SELECT * FROM book_transactions;

 BOOK_CODE STUDENT_CODE STAFF_CODE BOOK_ISSU BOOK_EXPE BOOK_ACTU
---------- ------------ ---------- --------- --------- ---------
  10000006         1012            02-FEB-11 09-FEB-11
  10000008                  100006 10-MAR-11 17-MAR-11 15-MAR-11
  10000009                  100010 01-APR-11 08-APR-11 10-APR-11
  10000004         1015            12-FEB-11 19-FEB-11
  10000005                  100007 14-MAR-11 28-MAY-18 01-JUN-18
  10000007                  100007 01-APR-11 28-MAY-18 01-JUN-18
  10000007                  100006 01-APR-10 07-APR-10 06-APR-10
  10000005         1009            31-MAY-11 08-JUN-11 08-JUN-11
     10002                     103 30-MAY-18 11-JUN-18

11 rows selected.

SQL> EXECUTE book_details(10002,1005,NULL);
09-JUN-18

PL/SQL procedure successfully completed.

SQL> SELECT * FROM book_transactions WHERE student_id=1005;
SELECT * FROM book_transactions WHERE student_id=1005
                                      *
ERROR at line 1:
ORA-00904: "STUDENT_ID": invalid identifier


SQL> SELECT * FROM book_transactions WHERE student_code=1005;

 BOOK_CODE STUDENT_CODE STAFF_CODE BOOK_ISSU BOOK_EXPE BOOK_ACTU
---------- ------------ ---------- --------- --------- ---------
     10002         1005            30-MAY-18 11-JUN-18