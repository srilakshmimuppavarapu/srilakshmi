CREATE OR REPLACE PROCEDURE staff_sal_update (staff_no IN number)IS
exp number;
hiredate date;
BEGIN
   SELECT staff_master.hiredate INTO hiredate FROM staff_master WHERE staff_master.staff_code=staff_no;
   exp:=months_between(sysdate,hiredate);
   exp:=exp/12;
   exp:=round(exp);
   if(exp<2) THEN
           DBMS_OUTPUT.PUT_LINE('no update');
   elsif(exp >2 and exp <5) THEN
        INSERT INTO staff_master_back (select * FROM staff_master WHERE staff_master.staff_code=staff_no);
		UPDATE staff_master SET staff_sal=staff_sal+(0.2 * staff_sal);
	else
		INSERT INTO staff_master_back (select * FROM staff_master WHERE staff_master.staff_code=staff_no);
		UPDATE staff_master SET staff_sal=staff_sal+(0.25 * staff_sal);
	END IF;
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			DBMS_OUTPUT.PUT_LINE('NO DATA FOUND');
	END;
/


Procedure created.


 BEGIN
 staff_sal_update(100004);
 END;
 /
 
 
PL/SQL procedure successfully completed.

SQL> select * from staff_master_back;

STAFF_CODE STAFF_NAME                                         DESIGN_CODE
---------- -------------------------------------------------- -----------
 DEPT_CODE HIREDATE  STAFF_DOB
---------- --------- ---------
STAFF_ADDRESS
--------------------------------------------------------------------------------

  MGR_CODE  STAFF_SAL
---------- ----------
    100004 Anil                                                       102
        20 11-MAR-01 22-APR-77
Hyderabad
    100006      20000


SQL>  select staff_sal,staff_code from staff_master;

 STAFF_SAL STAFF_CODE
---------- ----------
     46250     100001
     25000     100002
     30000     100003
     25000     100004
     40000     100005
     52500     100006
     77500     100007
     22500     100008
     27500     100009
     40000     100010

10 rows selected.
