
DECLARE
TYPE EmpRec IS RECORD(
v_empno emp.empno%TYPE,v_ename emp.ename%TYPE,v_job emp.job%TYPE,
v_mgr emp.mgr%TYPE,v_hiredate emp.hiredate%TYPE,v_sal emp.sal%TYPE,
v_comm emp.comm%TYPE,v_deptno emp.deptno%TYPE,v_dname department_master.dept_name%TYPE);
v_emprec EmpRec;
BEGIN
	SELECT emp.empno,emp.ename,emp.job,emp.mgr,emp.hiredate,emp.sal,emp.comm,emp.deptno,dept.dept_name INTO v_emprec.v_empno,v_emprec.v_ename,v_emprec.
v_job,v_emprec.v_mgr,v_emprec.v_hiredate,v_emprec.v_sal,v_emprec.v_sal,v_emprec.v_deptno,
v_emprec.v_dname FROM emp,department_master dept
WHERE emp.deptno=dept.dept_code AND
emp.ename='&empname';
DBMS_OUTPUT.PUT_LINE(v_emprec.v_empno||' '||v_emprec.v_ename||' '||v_emprec.v_job
||' '||v_emprec.v_mgr||' '||v_emprec.v_hiredate||' '||v_emprec.v_sal||' '||v_emprec.v_sal
||' '||v_emprec.v_deptno||' ' ||v_emprec.v_dname);
EXCEPTION
WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('NO DATA FOUND');
                END;
 /
Enter value for empname: SMITH
old  13: emp.ename='&empname';
new  13: emp.ename='SMITH';
7369 SMITH CLERK 7902 17-DEC-80   20 Electricals




PL/SQL procedure successfully completed.

SQL> /
Enter value for empname: SMITHA
old  13: emp.ename='&empname';
new  13: emp.ename='SMITHA';
NO DATA FOUND

PL/SQL procedure successfully completed.








