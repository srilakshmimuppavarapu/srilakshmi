package com.author.recharge.dao;

public interface IQueryMapper {
public static final String VIEWPLANS="select * from plans";
public static final String CHECKTABLE="Select count(*) from tab where tname='RECHARGEINFO'";
public static final String GENERTESEQUENCE="Select rech_Id.nextval from dual";
public static final String GETPLANNAME="select count(*) from plans where planname=?";
public static final String INSERTQUERY="insert into rechargeInfo values(?,?,?,?,?,?)";
public static final String CHECKRECHID="select count(*) from rechargeinfo where rechId=?";
public static final String GETDETAILS="Select * from rechargeinfo where rechId=?";
public static final String CREATETABLE="create table rechargeinfo(rechId varchar2(10),name varchar2(10),mobilenum varchar2(10),status varchar2(10),planname varchar2(10),amount number)";
public static final String SEQUENCECREATION="create sequence rech_Id start with 100000  increment by 1 NOCYCLE";
}
