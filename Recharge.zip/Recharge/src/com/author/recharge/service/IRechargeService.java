package com.author.recharge.service;



import com.author.recharge.bean.RechargeBean;
import com.author.recharge.exception.InvalidRecharge;

public interface IRechargeService {
	StringBuilder displayPlans() throws InvalidRecharge;
	void addUserDetails(RechargeBean r) throws InvalidRecharge;
	boolean retrieveUserDetails(String rechId,RechargeBean b1) throws InvalidRecharge;
	int retrieveAmount(String plan) throws InvalidRecharge;
	public boolean isValidMobile(String str);
	public boolean isValidName(String str);
	public boolean isValidRecharge(RechargeBean b1);
	
}
