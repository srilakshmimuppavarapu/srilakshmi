package com.cg.recharge.bean;

public class RechargeBean {
	private String name;
	private long contact;
	private String planName;
	private String emailId;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public String toString(){
		StringBuilder sb=new StringBuilder();
		sb.append("Printing Details of Recharge");
		sb.append("Name is: "+ name);
		sb.append("Mobile number is: "+ contact);
		sb.append("Plane name is: "+planName);
		sb.append("Email Id is: "+emailId);
		//sb.append("Status of Recharge is: "+status);
		return sb.toString();
		
	}
}
