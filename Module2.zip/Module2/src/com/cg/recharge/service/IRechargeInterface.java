package com.cg.recharge.service;

public interface IRechargeInterface 
{
	public String displayRechargePlans();
	public int getAmount(String planname);
}
