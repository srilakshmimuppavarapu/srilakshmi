package com.cg.recharge.service;

import com.cg.recharge.dao.IRecharge;
import com.cg.recharge.dao.RechargeDatabase;

public class Details implements IRechargeInterface
{
	@Override
	public String displayRechargePlans() 
	{
		IRecharge ie=new RechargeDatabase();
		String details=ie.displayRechargePlans();
		return details;
	}

	@Override
	public int getAmount(String planname) 
	{
		IRecharge ie=new RechargeDatabase();
		int amount=ie.getAmount(planname);
		return amount;
	}
}
