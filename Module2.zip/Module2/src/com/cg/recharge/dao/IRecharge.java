package com.cg.recharge.dao;

public interface IRecharge 
{
	public String displayRechargePlans();
	public int getAmount(String planname);
}
