package com.cg.recharge.pi;

import java.util.Scanner;

import com.cg.recharge.bean.RechargeBean;
import com.cg.recharge.dao.IRecharge;
import com.cg.recharge.dao.RechargeDatabase;
import com.cg.recharge.service.Details;
import com.cg.recharge.service.IRechargeInterface;

public class UserInput {

	public static void main(String args[])
	{
		Scanner s=new Scanner(System.in);
		
		System.out.println("Enter the user name");
		String name=s.next();
		System.out.println("Enter the phone number");
		long phone=s.nextLong();
		
		RechargeBean rb=new RechargeBean();
		
		rb.setName(name);
		rb.setContact(phone);
		
		
		IRechargeInterface ir=new Details();
		String display=ir.displayRechargePlans();
		System.out.println(display);
		
		System.out.println("Enter the plan name");
		String planName=s.next();
		System.out.println("Enter the emailid");
		String emailid = s.next();
		
		int amount =ir.getAmount(planName);
		System.out.println("your amount is: "+amount);
		
		
		rb.setPlanName(planName);
		rb.setEmailId(emailid);
		
	}
}
